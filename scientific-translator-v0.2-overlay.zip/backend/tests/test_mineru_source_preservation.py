from pathlib import Path

import fitz

from app.core.models import BlockKind, DocumentBlock, ParsedDocument
from app.parsers.mineru import MinerUParser
from app.renderers.common import html_for_document, markdown_for_document


def _make_unicode_pdf(path: Path) -> tuple[list[float], list[float]]:
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    fontfile = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    text = "For Δt = 10⁻⁹ s, the numerical error is below 0.01%."
    page.insert_text((60, 100), text, fontsize=12, fontname="dejavu", fontfile=fontfile)
    page.insert_text((60, 140), "E = mc²", fontsize=12, fontname="dejavu", fontfile=fontfile)
    doc.save(path)
    doc.close()

    doc = fitz.open(path)
    page = doc[0]
    blocks = [b for b in page.get_text("dict")["blocks"] if "lines" in b]
    rect = page.rect

    def norm(bbox):
        x0, y0, x1, y1 = bbox
        return [x0 / rect.width * 1000, y0 / rect.height * 1000, x1 / rect.width * 1000, y1 / rect.height * 1000]

    result = norm(blocks[0]["bbox"]), norm(blocks[1]["bbox"])
    doc.close()
    return result


def test_mineru_text_block_prefers_aligned_original_pdf_text_layer(tmp_path: Path):
    pdf = tmp_path / "paper.pdf"
    text_bbox, _ = _make_unicode_pdf(pdf)
    doc = fitz.open(pdf)
    parser = MinerUParser()
    item = {
        "type": "text",
        "page_idx": 0,
        "bbox": text_bbox,
        "text": "For $\\Delta \\mathfrak { t } = 1 0 ^ { - 9 } \\ s$, the numerical error is below 0.01%.",
    }
    block = parser._convert_item(item, 0, tmp_path, tmp_path, pdf_doc=doc, inline_spans={})
    doc.close()

    assert block is not None
    assert block.text == "For Δt = 10⁻⁹ s, the numerical error is below 0.01%."
    assert block.metadata["source_text_layer_recovered"] is True
    assert "mathfrak" in block.metadata["mineru_text"]


def test_inline_math_falls_back_to_original_pdf_crop_when_text_layer_is_not_trusted(tmp_path: Path, monkeypatch):
    pdf = tmp_path / "paper.pdf"
    _, equation_bbox = _make_unicode_pdf(pdf)
    doc = fitz.open(pdf)
    parser = MinerUParser()
    monkeypatch.setattr(parser, "_recover_source_text", lambda *args, **kwargs: None)

    item = {
        "type": "text",
        "page_idx": 0,
        "bbox": [80, 130, 600, 190],
        "text": "Relation $E=mc^2$ is invariant.",
    }
    spans = {0: [{"bbox": equation_bbox, "latex": "E=mc^2"}]}
    block = parser._convert_item(item, 1, tmp_path, tmp_path, pdf_doc=doc, inline_spans=spans)
    doc.close()

    assert block is not None
    assert "__SDT_INLINE_EQ_b00001_00__" in block.text
    assets = block.metadata["inline_equations"]
    assert len(assets) == 1
    assert (tmp_path / "output" / assets[0]["asset_path"]).is_file()

    block.translated_text = "Quan hệ __SDT_INLINE_EQ_b00001_00__ là bất biến."
    parsed = ParsedDocument(source_path=str(pdf), blocks=[block], parser="test")
    md = markdown_for_document(parsed)
    html = html_for_document(parsed)
    assert "![E=mc^2](assets/b00001_inline_00.png)" in md
    assert 'class="inline-equation"' in html
    assert "assets/b00001_inline_00.png" in html
