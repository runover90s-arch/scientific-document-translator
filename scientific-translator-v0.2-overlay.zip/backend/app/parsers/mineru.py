from __future__ import annotations

import html
import json
import re
import shutil
import subprocess
from collections import Counter
from pathlib import Path
from typing import Any

import fitz

from app.core.config import settings
from app.core.models import BlockKind, DocumentBlock, ParsedDocument
from .base import DocumentParser


AUX_TYPES = {"page_header", "page_footer", "page_number", "page_aside_text", "page_footnote", "header", "footer"}
INLINE_LATEX_RE = re.compile(r"(?<!\$)\$(?!\$)(.+?)(?<!\$)\$(?!\$)", re.DOTALL)
WORD_RE = re.compile(r"[^\W\d_]{2,}", re.UNICODE)


class MinerUParser(DocumentParser):
    def available(self) -> bool:
        return shutil.which(settings.mineru_command) is not None

    def parse(self, source_path: Path, work_dir: Path) -> ParsedDocument:
        parse_dir = work_dir / "mineru"
        parse_dir.mkdir(parents=True, exist_ok=True)
        command = [
            settings.mineru_command,
            "-p", str(source_path),
            "-o", str(parse_dir),
            "-b", settings.mineru_backend,
        ]
        completed = subprocess.run(command, capture_output=True, text=True, timeout=3600)
        if completed.returncode != 0:
            raise RuntimeError(f"MinerU failed: {completed.stderr[-4000:]}")

        legacy_files = sorted(parse_dir.rglob("*_content_list.json"))
        if not legacy_files:
            raise RuntimeError("MinerU completed but no *_content_list.json was found")
        content_file = legacy_files[0]
        raw = json.loads(content_file.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise RuntimeError("Unexpected MinerU content_list format")

        pdf_doc: fitz.Document | None = None
        if source_path.suffix.lower() == ".pdf":
            try:
                pdf_doc = fitz.open(source_path)
            except Exception:
                pdf_doc = None

        middle_files = sorted(parse_dir.rglob("*_middle.json"))
        inline_spans = self._load_inline_spans(middle_files[0]) if middle_files else {}

        blocks: list[DocumentBlock] = []
        try:
            for idx, item in enumerate(raw):
                if not isinstance(item, dict):
                    continue
                block = self._convert_item(
                    item,
                    idx,
                    content_file.parent,
                    work_dir,
                    pdf_doc=pdf_doc,
                    inline_spans=inline_spans,
                )
                if block is not None:
                    blocks.append(block)
        finally:
            if pdf_doc is not None:
                pdf_doc.close()

        metadata: dict[str, Any] = {
            "mineru_content_list": content_file.name,
        }
        v2 = sorted(parse_dir.rglob("*_content_list_v2.json"))
        if v2:
            metadata["mineru_content_list_v2"] = v2[0].name
        if middle_files:
            metadata["mineru_middle_json"] = middle_files[0].name

        warnings: list[str] = []
        recovered = sum(bool(b.metadata.get("source_text_layer_recovered")) for b in blocks)
        visual_inline = sum(len(b.metadata.get("inline_equations", [])) for b in blocks)
        unresolved = sum(
            1
            for b in blocks
            if b.kind in {BlockKind.TEXT, BlockKind.TITLE}
            and INLINE_LATEX_RE.search(b.text)
            and not b.metadata.get("source_text_layer_recovered")
            and not b.metadata.get("inline_equations")
        )
        metadata["source_text_blocks_recovered"] = recovered
        metadata["inline_equation_crops"] = visual_inline
        if unresolved:
            warnings.append(
                f"{unresolved} text block(s) still contain OCR/LaTeX inline math because no reliable original text layer or crop could be recovered."
            )

        return ParsedDocument(str(source_path), blocks, parser="mineru", warnings=warnings, metadata=metadata)

    def _copy_asset(self, asset: str | None, base: Path, work_dir: Path, block_id: str) -> str | None:
        if not asset:
            return None
        candidate = (base / asset).resolve()
        if not candidate.exists():
            matches = list(base.rglob(Path(asset).name))
            if not matches:
                return None
            candidate = matches[0]
        out_dir = work_dir / "output" / "assets"
        out_dir.mkdir(parents=True, exist_ok=True)
        target = out_dir / f"{block_id}_{candidate.name}"
        shutil.copy2(candidate, target)
        return f"assets/{target.name}"

    @staticmethod
    def _words(text: str) -> list[str]:
        # Ignore MinerU inline-LaTeX payloads when judging natural-language alignment.
        text = INLINE_LATEX_RE.sub(" ", text)
        text = re.sub(r"\\[A-Za-z]+", " ", text)
        return [w.casefold() for w in WORD_RE.findall(text)]

    @classmethod
    def _looks_aligned(cls, source_text: str, mineru_text: str) -> bool:
        a = cls._words(source_text)
        b = cls._words(mineru_text)
        if not a or not b:
            return False
        ca = Counter(a)
        cb = Counter(b)
        overlap = sum((ca & cb).values())
        denominator = min(sum(ca.values()), sum(cb.values()))
        # Requiring strong containment prevents accidentally taking text from an adjacent block.
        return denominator > 0 and (overlap / denominator) >= 0.60

    @staticmethod
    def _bbox_to_page_rect(page: fitz.Page, bbox: list[float] | None) -> fitz.Rect | None:
        if not bbox or len(bbox) != 4:
            return None
        try:
            x0, y0, x1, y1 = [float(x) for x in bbox]
        except (TypeError, ValueError):
            return None
        rect = page.rect
        clip = fitz.Rect(
            rect.x0 + x0 / 1000.0 * rect.width,
            rect.y0 + y0 / 1000.0 * rect.height,
            rect.x0 + x1 / 1000.0 * rect.width,
            rect.y0 + y1 / 1000.0 * rect.height,
        )
        return clip & rect

    def _recover_source_text(
        self,
        pdf_doc: fitz.Document | None,
        page_index: int,
        bbox: list[float] | None,
        mineru_text: str,
    ) -> str | None:
        if pdf_doc is None or page_index < 0 or page_index >= len(pdf_doc):
            return None
        page = pdf_doc[page_index]
        clip = self._bbox_to_page_rect(page, bbox)
        if clip is None or clip.is_empty:
            return None
        # content_list coordinates are quantized to a 0-1000 grid; a tiny expansion
        # avoids losing edge glyphs while the alignment check rejects adjacent text.
        clip = fitz.Rect(clip.x0 - 1.0, clip.y0 - 1.0, clip.x1 + 1.0, clip.y1 + 1.0) & page.rect
        try:
            raw = page.get_text("text", clip=clip, sort=True)
        except Exception:
            return None
        # Preserve characters from the PDF text layer while flattening visual line wraps.
        source_text = " ".join(line.strip() for line in raw.splitlines() if line.strip()).strip()
        if not source_text or "\ufffd" in source_text:
            return None
        return source_text if self._looks_aligned(source_text, mineru_text) else None

    @staticmethod
    def _load_inline_spans(middle_path: Path) -> dict[int, list[dict[str, Any]]]:
        try:
            data = json.loads(middle_path.read_text(encoding="utf-8"))
        except Exception:
            return {}
        pages = data.get("pdf_info", []) if isinstance(data, dict) else []
        result: dict[int, list[dict[str, Any]]] = {}

        def walk(node: Any, page_size: tuple[float, float], acc: list[dict[str, Any]]) -> None:
            if isinstance(node, dict):
                spans = node.get("spans")
                if isinstance(spans, list):
                    for span in spans:
                        if not isinstance(span, dict) or span.get("type") != "inline_equation":
                            continue
                        bbox = span.get("bbox")
                        if not isinstance(bbox, list) or len(bbox) != 4:
                            continue
                        width, height = page_size
                        if not width or not height:
                            continue
                        normalized = [
                            float(bbox[0]) * 1000.0 / width,
                            float(bbox[1]) * 1000.0 / height,
                            float(bbox[2]) * 1000.0 / width,
                            float(bbox[3]) * 1000.0 / height,
                        ]
                        acc.append({"bbox": normalized, "latex": str(span.get("content", ""))})
                for key, value in node.items():
                    if key != "spans":
                        walk(value, page_size, acc)
            elif isinstance(node, list):
                for value in node:
                    walk(value, page_size, acc)

        for fallback_idx, page_info in enumerate(pages):
            if not isinstance(page_info, dict):
                continue
            page_idx = int(page_info.get("page_idx", fallback_idx) or fallback_idx)
            size = page_info.get("page_size", [0, 0])
            if not isinstance(size, list) or len(size) < 2:
                continue
            page_size = (float(size[0] or 0), float(size[1] or 0))
            acc: list[dict[str, Any]] = []
            # para_blocks are the post-segmentation blocks used for final content.
            walk(page_info.get("para_blocks", []), page_size, acc)
            # Deduplicate spans that can appear through nested structures.
            seen: set[tuple] = set()
            unique: list[dict[str, Any]] = []
            for span in acc:
                key = tuple(round(x, 3) for x in span["bbox"]) + (span["latex"],)
                if key not in seen:
                    seen.add(key)
                    unique.append(span)
            result[page_idx] = unique
        return result

    @staticmethod
    def _inside(block_bbox: list[float] | None, span_bbox: list[float], tolerance: float = 4.0) -> bool:
        if not block_bbox or len(block_bbox) != 4:
            return False
        cx = (span_bbox[0] + span_bbox[2]) / 2.0
        cy = (span_bbox[1] + span_bbox[3]) / 2.0
        return (
            float(block_bbox[0]) - tolerance <= cx <= float(block_bbox[2]) + tolerance
            and float(block_bbox[1]) - tolerance <= cy <= float(block_bbox[3]) + tolerance
        )

    @staticmethod
    def _latex_key(value: str) -> str:
        value = value.strip().strip("$")
        return re.sub(r"\s+", "", value)

    def _crop_inline_equation(
        self,
        pdf_doc: fitz.Document,
        page_index: int,
        bbox: list[float],
        work_dir: Path,
        block_id: str,
        equation_index: int,
    ) -> str | None:
        if page_index < 0 or page_index >= len(pdf_doc):
            return None
        page = pdf_doc[page_index]
        clip = self._bbox_to_page_rect(page, bbox)
        if clip is None or clip.is_empty:
            return None
        # Small padding keeps superscripts/descenders from being clipped at OCR boundaries.
        pad = 1.5
        clip = fitz.Rect(clip.x0 - pad, clip.y0 - pad, clip.x1 + pad, clip.y1 + pad) & page.rect
        out_dir = work_dir / "output" / "assets"
        out_dir.mkdir(parents=True, exist_ok=True)
        target = out_dir / f"{block_id}_inline_{equation_index:02d}.png"
        try:
            pix = page.get_pixmap(matrix=fitz.Matrix(2.5, 2.5), clip=clip, alpha=False)
            pix.save(target)
        except Exception:
            return None
        return f"assets/{target.name}" if target.is_file() else None

    def _replace_inline_math_with_original_crops(
        self,
        text: str,
        page_index: int,
        block_bbox: list[float] | None,
        block_id: str,
        pdf_doc: fitz.Document | None,
        inline_spans: dict[int, list[dict[str, Any]]],
        work_dir: Path,
    ) -> tuple[str, list[dict[str, Any]]]:
        if pdf_doc is None:
            return text, []
        matches = list(INLINE_LATEX_RE.finditer(text))
        if not matches:
            return text, []
        candidates = [s for s in inline_spans.get(page_index, []) if self._inside(block_bbox, s["bbox"])]
        candidates.sort(key=lambda s: ((s["bbox"][1] + s["bbox"][3]) / 2, (s["bbox"][0] + s["bbox"][2]) / 2))
        if not candidates:
            return text, []

        remaining = candidates[:]
        replacements: list[tuple[int, int, str]] = []
        metadata: list[dict[str, Any]] = []
        for eq_index, match in enumerate(matches):
            if not remaining:
                break
            key = self._latex_key(match.group(1))
            chosen_index = next(
                (i for i, span in enumerate(remaining) if self._latex_key(span.get("latex", "")) == key),
                0,
            )
            span = remaining.pop(chosen_index)
            asset = self._crop_inline_equation(pdf_doc, page_index, span["bbox"], work_dir, block_id, eq_index)
            if not asset:
                continue
            token = f"__SDT_INLINE_EQ_{block_id}_{eq_index:02d}__"
            replacements.append((match.start(), match.end(), token))
            metadata.append({
                "token": token,
                "asset_path": asset,
                "latex": match.group(1).strip(),
                "bbox": span["bbox"],
            })

        if not replacements:
            return text, []
        out = text
        for start, end, token in reversed(replacements):
            out = out[:start] + token + out[end:]
        return out, metadata

    def _convert_item(
        self,
        item: dict[str, Any],
        idx: int,
        base: Path,
        work_dir: Path,
        *,
        pdf_doc: fitz.Document | None = None,
        inline_spans: dict[int, list[dict[str, Any]]] | None = None,
    ) -> DocumentBlock | None:
        t = str(item.get("type", "unknown"))
        block_id = f"b{idx:05d}"
        page = int(item.get("page_idx", 0) or 0)
        bbox = item.get("bbox")
        asset = self._copy_asset(item.get("img_path"), base, work_dir, block_id)
        inline_spans = inline_spans or {}

        if t == "text":
            level = item.get("text_level")
            kind = BlockKind.TITLE if level not in {None, 0} else BlockKind.TEXT
            mineru_text = str(item.get("text", ""))
            metadata: dict[str, Any] = {}
            recovered = self._recover_source_text(pdf_doc, page, bbox, mineru_text)
            if recovered:
                text = recovered
                metadata["source_text_layer_recovered"] = True
                metadata["mineru_text"] = mineru_text
            else:
                text, inline_assets = self._replace_inline_math_with_original_crops(
                    mineru_text, page, bbox, block_id, pdf_doc, inline_spans, work_dir
                )
                if inline_assets:
                    metadata["inline_equations"] = inline_assets
                    metadata["inline_math_mode"] = "original_pdf_crop"
            return DocumentBlock(block_id, kind, text, page, bbox, True, level=level, metadata=metadata)
        if t == "equation":
            return DocumentBlock(block_id, BlockKind.EQUATION, str(item.get("text", "")), page, bbox, False, asset_path=asset)
        if t == "image":
            captions = list(item.get("image_caption", []) or [])
            footnotes = list(item.get("image_footnote", []) or [])
            visible_text = "\n".join([*map(str, captions), *map(str, footnotes)]).strip()
            return DocumentBlock(
                block_id, BlockKind.IMAGE, visible_text, page, bbox, bool(visible_text), asset_path=asset,
                metadata={"caption": captions, "footnote": footnotes},
            )
        if t == "table":
            caption = "\n".join(map(str, item.get("table_caption", []) or []))
            body = str(item.get("table_body", ""))
            footnote = "\n".join(map(str, item.get("table_footnote", []) or []))
            parts: list[str] = []
            if caption:
                parts.append(f'<p class="table-caption">{html.escape(caption)}</p>')
            if body:
                parts.append(body)
            if footnote:
                parts.append(f'<p class="table-footnote">{html.escape(footnote)}</p>')
            combined = "\n".join(parts).strip()
            return DocumentBlock(
                block_id, BlockKind.TABLE, combined, page, bbox, True, asset_path=asset,
                metadata={"caption": caption, "table_body": body, "footnote": footnote},
            )
        if t == "chart":
            caption = "\n".join(item.get("chart_caption", []) or [])
            body = str(item.get("content", ""))
            return DocumentBlock(block_id, BlockKind.TABLE, (caption + "\n" + body).strip(), page, bbox, True,
                                 asset_path=asset, metadata={"chart": True})
        if t == "code":
            caption = "\n".join(item.get("code_caption", []) or [])
            code_body = str(item.get("code_body", ""))
            return DocumentBlock(block_id, BlockKind.CODE, code_body, page, bbox, False,
                                 metadata={"caption": caption, "sub_type": item.get("sub_type")})
        if t == "list":
            items = item.get("list_items", []) or []
            subtype = item.get("sub_type")
            kind = BlockKind.REFERENCE if subtype == "ref_text" else BlockKind.LIST
            return DocumentBlock(block_id, kind, "\n".join(map(str, items)), page, bbox, kind != BlockKind.REFERENCE)
        if t in AUX_TYPES:
            text = str(item.get("text", ""))
            return DocumentBlock(block_id, BlockKind.AUXILIARY, text, page, bbox, False)
        return DocumentBlock(block_id, BlockKind.UNKNOWN, str(item.get("text", "")), page, bbox, False)
