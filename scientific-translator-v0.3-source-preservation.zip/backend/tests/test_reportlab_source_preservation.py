from pathlib import Path

import fitz
import pytest

from app.parsers.mineru import MinerUParser

reportlab = pytest.importorskip("reportlab")
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


def _make_reportlab_pdf(path: Path) -> list[float]:
    fontfile = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    pdfmetrics.registerFont(TTFont("DejaVuV03", fontfile))
    c = canvas.Canvas(str(path))
    c.setFont("DejaVuV03", 12)
    text = "For Δt = 10⁻⁹ s, the numerical error is below 0.01%."
    c.drawString(60, 630, text)
    c.save()

    doc = fitz.open(path)
    page = doc[0]
    native = [b for b in page.get_text("dict")["blocks"] if "lines" in b][0]
    x0, y0, x1, y1 = native["bbox"]
    rect = page.rect
    bbox = [x0 / rect.width * 1000, y0 / rect.height * 1000, x1 / rect.width * 1000, y1 / rect.height * 1000]
    doc.close()
    return bbox


def test_reportlab_pdf_text_layer_restores_original_unicode_inline_math(tmp_path: Path):
    pdf = tmp_path / "reportlab.pdf"
    bbox = _make_reportlab_pdf(pdf)
    doc = fitz.open(pdf)
    parser = MinerUParser()
    item = {
        "type": "text",
        "page_idx": 0,
        "bbox": bbox,
        "text": "For $\\Delta \\mathfrak { t } = 1 0 ^ { - 9 } \\ s$, the numerical error is below 0.01%.",
    }
    block = parser._convert_item(item, 0, tmp_path, tmp_path, pdf_doc=doc, inline_spans={})
    doc.close()

    assert block is not None
    assert block.text == "For Δt = 10⁻⁹ s, the numerical error is below 0.01%."
    assert block.metadata.get("source_text_layer_recovered") is True
