import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const SciTranslatorApp());

class SciTranslatorApp extends StatelessWidget {
  const SciTranslatorApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Scientific Translator',
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final apiController = TextEditingController(text: 'http://10.0.2.2:8000');
  final glossaryController = TextEditingController();
  PlatformFile? selected;
  String source = 'auto';
  String target = 'vi';
  String status = 'Chưa có tác vụ';
  double progress = 0;
  Map<String, dynamic> outputs = {};
  String? currentJobId;
  String? currentUploadId;
  Timer? timer;
  bool submitting = false;

  static const sourceLanguages = <String, String>{
    'auto': 'Tự động',
    'en': 'English',
    'vi': 'Tiếng Việt',
    'zh': '中文',
    'ja': '日本語',
    'ko': '한국어',
    'de': 'Deutsch',
    'fr': 'Français',
    'es': 'Español',
    'ru': 'Русский',
  };

  static const targetLanguages = <String, String>{
    'vi': 'Tiếng Việt',
    'en': 'English',
    'zh': '中文',
    'ja': '日本語',
    'ko': '한국어',
    'de': 'Deutsch',
    'fr': 'Français',
    'es': 'Español',
    'ru': 'Русский',
  };

  String get baseUrl => apiController.text.trim().replaceAll(RegExp(r'/+$'), '');

  Future<void> pick() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      withData: false,
      allowedExtensions: ['pdf', 'docx', 'txt', 'md', 'png', 'jpg', 'jpeg', 'pptx', 'xlsx'],
    );
    if (result != null && mounted) {
      setState(() => selected = result.files.single);
    }
  }

  String _resumeKey(PlatformFile file) => 'sdt-upload:${file.name}:${file.size}:$source:$target';

  String _signature(PlatformFile file) => jsonEncode({
        'name': file.name,
        'size': file.size,
        'source': source,
        'target': target,
        'glossary': glossaryController.text.trim(),
      });

  Future<Uint8List> _readChunk(PlatformFile file, int start, int end) async {
    final length = end - start;
    if (file.path != null) {
      final raf = await File(file.path!).open();
      try {
        await raf.setPosition(start);
        return Uint8List.fromList(await raf.read(length));
      } finally {
        await raf.close();
      }
    }
    if (file.bytes != null) {
      return Uint8List.sublistView(file.bytes!, start, end);
    }
    throw StateError('Không đọc được dữ liệu tệp đã chọn.');
  }

  Future<Map<String, dynamic>?> _getUpload(String uploadId) async {
    final res = await http.get(Uri.parse('$baseUrl/api/v1/uploads/$uploadId'));
    if (res.statusCode != 200) return null;
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  Future<Map<String, dynamic>> _initUpload(PlatformFile file) async {
    final res = await http.post(
      Uri.parse('$baseUrl/api/v1/uploads/init'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'filename': file.name,
        'size': file.size,
        'source_language': source,
        'target_language': target,
        'output_format': 'html',
        'glossary_json': glossaryController.text.trim(),
      }),
    );
    if (res.statusCode >= 300) throw StateError(res.body);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  Future<Map<String, dynamic>> _completeUpload(String uploadId) async {
    final res = await http.post(Uri.parse('$baseUrl/api/v1/uploads/$uploadId/complete'));
    if (res.statusCode >= 300) throw StateError(res.body);
    return Map<String, dynamic>.from(jsonDecode(res.body) as Map);
  }

  Future<void> submit() async {
    if (selected == null || submitting) return;
    if (baseUrl.isEmpty) {
      setState(() => status = 'Hãy nhập địa chỉ API server.');
      return;
    }

    final file = selected!;
    setState(() {
      submitting = true;
      status = 'Đang chuẩn bị upload chia nhỏ...';
      progress = .01;
      outputs = {};
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      final key = _resumeKey(file);
      final savedRaw = prefs.getString(key);
      Map<String, dynamic>? session;

      if (savedRaw != null) {
        try {
          final saved = Map<String, dynamic>.from(jsonDecode(savedRaw) as Map);
          if (saved['signature'] == _signature(file)) {
            session = await _getUpload(saved['uploadId'].toString());
          }
        } catch (_) {
          session = null;
        }
      }

      session ??= await _initUpload(file);
      currentUploadId = session['upload_id'].toString();
      await prefs.setString(
        key,
        jsonEncode({'uploadId': currentUploadId, 'signature': _signature(file)}),
      );

      if (session['status'] == 'completed' && session['job_id'] != null) {
        currentJobId = session['job_id'].toString();
        poll(currentJobId!, uploadId: currentUploadId, resumePreferenceKey: key);
        return;
      }

      final chunkSize = (session['chunk_size'] as num).toInt();
      final totalChunks = (session['total_chunks'] as num).toInt();
      final received = <int>{
        for (final value in (session['received_indices'] as List? ?? const [])) (value as num).toInt(),
      };

      for (var index = 0; index < totalChunks; index++) {
        if (received.contains(index)) continue;
        final start = index * chunkSize;
        final end = (start + chunkSize < file.size) ? start + chunkSize : file.size;
        final bytes = await _readChunk(file, start, end);
        final digest = sha256.convert(bytes).toString();
        if (mounted) {
          setState(() {
            status = 'Đang tải phần ${index + 1}/$totalChunks...';
            progress = ((received.length + 1) / totalChunks) * .20;
          });
        }
        final res = await http.put(
          Uri.parse('$baseUrl/api/v1/uploads/$currentUploadId/chunks/$index'),
          headers: {
            'Content-Type': 'application/octet-stream',
            'X-Chunk-SHA256': digest,
          },
          body: bytes,
        );
        if (res.statusCode >= 300) throw StateError(res.body);
        received.add(index);
      }

      if (mounted) setState(() => status = 'Đang ghép file và kiểm tra SHA-256...');
      final job = await _completeUpload(currentUploadId!);
      currentJobId = job['id'].toString();
      if (mounted) setState(() => progress = .20);
      poll(currentJobId!, uploadId: currentUploadId, resumePreferenceKey: key);
    } catch (e) {
      if (mounted) setState(() => status = 'Lỗi: $e');
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  void poll(String id, {String? uploadId, String? resumePreferenceKey, bool recovered = false}) {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 2), (t) async {
      try {
        var res = await http.get(Uri.parse('$baseUrl/api/v1/jobs/$id'));
        if (res.statusCode == 404 && uploadId != null && !recovered) {
          final restored = await _completeUpload(uploadId);
          t.cancel();
          final restoredId = restored['id'].toString();
          currentJobId = restoredId;
          poll(
            restoredId,
            uploadId: uploadId,
            resumePreferenceKey: resumePreferenceKey,
            recovered: true,
          );
          return;
        }
        if (res.statusCode != 200) return;
        final job = jsonDecode(res.body) as Map<String, dynamic>;
        if (!mounted) return;
        setState(() {
          status = '${job['message'] ?? job['status']}${job['error'] != null ? ' — ${job['error']}' : ''}';
          progress = .20 + (((job['progress'] ?? 0) as num).toDouble() / 100) * .80;
          outputs = Map<String, dynamic>.from(job['outputs'] ?? {});
        });
        if (job['status'] == 'completed' || job['status'] == 'failed') {
          t.cancel();
          if (job['status'] == 'completed' && resumePreferenceKey != null) {
            final prefs = await SharedPreferences.getInstance();
            await prefs.remove(resumePreferenceKey);
          }
        }
      } catch (_) {
        // Keep polling; transient mobile network failures are common.
      }
    });
  }

  Future<void> openOutput(String fmt) async {
    final output = outputs[fmt];
    if (output == null) return;
    final raw = output.toString();
    final uri = raw.startsWith('http://') || raw.startsWith('https://')
        ? Uri.parse(raw)
        : Uri.parse('$baseUrl$raw');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  void dispose() {
    timer?.cancel();
    apiController.dispose();
    glossaryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Scientific Translator')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            TextField(
              controller: apiController,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(labelText: 'API server', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: submitting ? null : pick,
              icon: const Icon(Icons.upload_file),
              label: Text(selected?.name ?? 'Chọn tài liệu'),
            ),
            if (selected != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('${(selected!.size / 1024 / 1024).toStringAsFixed(2)} MB'),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: source,
                    decoration: const InputDecoration(labelText: 'Nguồn'),
                    items: sourceLanguages.entries
                        .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                        .toList(),
                    onChanged: (v) => setState(() => source = v!),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: target,
                    decoration: const InputDecoration(labelText: 'Đích'),
                    items: targetLanguages.entries
                        .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                        .toList(),
                    onChanged: (v) => setState(() => target = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            TextField(
              controller: glossaryController,
              minLines: 2,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Glossary JSON (tùy chọn)',
                hintText: '{"wave function":"hàm sóng"}',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: selected == null || submitting ? null : submit,
              child: Text(submitting ? 'ĐANG TẢI...' : 'DỊCH TÀI LIỆU'),
            ),
            const SizedBox(height: 18),
            LinearProgressIndicator(value: progress.clamp(0.0, 1.0).toDouble()),
            const SizedBox(height: 8),
            Text(status),
            if (outputs.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.only(top: 16, bottom: 8),
                child: Text('Kết quả', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: outputs.keys
                    .map((fmt) => OutlinedButton(
                          onPressed: () => openOutput(fmt),
                          child: Text(fmt.replaceAll('_', ' ').toUpperCase()),
                        ))
                    .toList(),
              ),
            ],
          ],
        ),
      );
}
