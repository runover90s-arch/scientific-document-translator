import hashlib

import pytest

from app.core.uploads import ChunkUploadManager


def _manager(tmp_path, *, chunk_size=4, max_total=100):
    return ChunkUploadManager(tmp_path / "uploads", chunk_size=chunk_size, max_total_bytes=max_total)


def test_chunk_upload_resume_and_assembly(tmp_path):
    data = b"abcdefghijklmnopqrstuvwxyz"
    manager = _manager(tmp_path, chunk_size=5)
    session = manager.create(
        filename="paper.pdf",
        size=len(data),
        source_language="en",
        target_language="vi",
        output_format="html",
    )

    # Upload out of order to prove the protocol is resumable rather than tied to
    # one live request/connection.
    for index in [1, 0, 3]:
        chunk = data[index * 5 : min(len(data), (index + 1) * 5)]
        manager.put_chunk(session.id, index, chunk, hashlib.sha256(chunk).hexdigest())

    status = manager.public_status(manager.load(session.id))
    assert status["received_indices"] == [0, 1, 3]
    assert status["status"] == "uploading"

    for index in [2, 4, 5]:
        chunk = data[index * 5 : min(len(data), (index + 1) * 5)]
        manager.put_chunk(session.id, index, chunk, hashlib.sha256(chunk).hexdigest())

    destination = tmp_path / "jobs" / "abc" / "input" / "paper.pdf"
    digest = manager.assemble(manager.load(session.id), destination)
    assert destination.read_bytes() == data
    assert digest == hashlib.sha256(data).hexdigest()


def test_chunk_upload_is_idempotent(tmp_path):
    data = b"abcdefgh"
    manager = _manager(tmp_path, chunk_size=4)
    session = manager.create(
        filename="paper.pdf",
        size=len(data),
        source_language="en",
        target_language="vi",
        output_format="html",
    )
    chunk = data[:4]
    sha = hashlib.sha256(chunk).hexdigest()
    first = manager.put_chunk(session.id, 0, chunk, sha)
    second = manager.put_chunk(session.id, 0, chunk, sha)
    assert first["already_received"] is False
    assert second["already_received"] is True


def test_chunk_upload_rejects_corruption_and_wrong_size(tmp_path):
    manager = _manager(tmp_path, chunk_size=4)
    session = manager.create(
        filename="paper.pdf",
        size=8,
        source_language="en",
        target_language="vi",
        output_format="html",
    )
    with pytest.raises(ValueError, match="SHA-256 mismatch"):
        manager.put_chunk(session.id, 0, b"abcd", "0" * 64)
    with pytest.raises(ValueError, match="expected 4"):
        manager.put_chunk(session.id, 0, b"abc")


def test_chunk_upload_refuses_incomplete_assembly(tmp_path):
    manager = _manager(tmp_path, chunk_size=4)
    session = manager.create(
        filename="paper.pdf",
        size=8,
        source_language="en",
        target_language="vi",
        output_format="html",
    )
    manager.put_chunk(session.id, 0, b"abcd")
    with pytest.raises(ValueError, match="missing chunks"):
        manager.assemble(manager.load(session.id), tmp_path / "paper.pdf")


def test_chunk_upload_api_end_to_end(tmp_path, monkeypatch):
    import types

    from fastapi.testclient import TestClient

    import app.api.routes as routes
    from app.main import app

    data = b"0123456789"
    manager = ChunkUploadManager(tmp_path / "uploads", chunk_size=4, max_total_bytes=100)
    monkeypatch.setattr(routes, "upload_manager", manager)
    monkeypatch.setattr(
        routes,
        "settings",
        types.SimpleNamespace(
            storage_dir=tmp_path,
            max_upload_mb=100,
            chunk_upload_mb=4,
            max_chunked_upload_mb=1024,
            app_name="test",
            llm_api_key="",
            llm_model="",
        ),
    )

    async def noop_run_job(*args, **kwargs):
        return None

    monkeypatch.setattr(routes, "run_job", noop_run_job)
    client = TestClient(app)

    init = client.post(
        "/api/v1/uploads/init",
        json={
            "filename": "paper.pdf",
            "size": len(data),
            "source_language": "en",
            "target_language": "vi",
        },
    )
    assert init.status_code == 200
    session = init.json()
    upload_id = session["upload_id"]
    assert session["total_chunks"] == 3

    for index in range(3):
        chunk = data[index * 4 : min(len(data), (index + 1) * 4)]
        response = client.put(
            f"/api/v1/uploads/{upload_id}/chunks/{index}",
            content=chunk,
            headers={"X-Chunk-SHA256": hashlib.sha256(chunk).hexdigest()},
        )
        assert response.status_code == 200

    completed = client.post(f"/api/v1/uploads/{upload_id}/complete")
    assert completed.status_code == 200
    body = completed.json()
    assert body["source_sha256"] == hashlib.sha256(data).hexdigest()
    input_path = tmp_path / "jobs" / body["id"] / "input" / "paper.pdf"
    assert input_path.read_bytes() == data
