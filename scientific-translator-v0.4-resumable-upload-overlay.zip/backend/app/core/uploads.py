from __future__ import annotations

import hashlib
import json
import math
import shutil
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from typing import Any


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class UploadSession:
    id: str
    filename: str
    size: int
    chunk_size: int
    total_chunks: int
    source_language: str = "auto"
    target_language: str = "vi"
    output_format: str = "html"
    glossary: dict[str, str] = field(default_factory=dict)
    expected_sha256: str | None = None
    status: str = "uploading"
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)
    job_id: str | None = None
    sha256: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UploadSession":
        return cls(**data)


class ChunkUploadManager:
    """Filesystem-backed resumable uploads.

    Session metadata and chunk files live under storage/uploads so a browser can
    resume after a page reload or backend restart. The manager deliberately does
    not depend on the in-memory job store.
    """

    def __init__(self, root: Path, chunk_size: int, max_total_bytes: int) -> None:
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        if max_total_bytes <= 0:
            raise ValueError("max_total_bytes must be positive")
        self.root = Path(root)
        self.chunk_size = int(chunk_size)
        self.max_total_bytes = int(max_total_bytes)
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = Lock()

    def _dir(self, upload_id: str) -> Path:
        if not upload_id or any(c not in "0123456789abcdef" for c in upload_id.lower()):
            raise KeyError("invalid upload id")
        return self.root / upload_id

    def _meta_path(self, upload_id: str) -> Path:
        return self._dir(upload_id) / "upload.json"

    def _chunks_dir(self, upload_id: str) -> Path:
        return self._dir(upload_id) / "chunks"

    def _chunk_path(self, upload_id: str, index: int) -> Path:
        return self._chunks_dir(upload_id) / f"{index:08d}.part"

    def _save(self, session: UploadSession) -> None:
        session.updated_at = _now()
        path = self._meta_path(session.id)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(asdict(session), ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    def create(
        self,
        *,
        filename: str,
        size: int,
        source_language: str,
        target_language: str,
        output_format: str,
        glossary: dict[str, str] | None = None,
        expected_sha256: str | None = None,
    ) -> UploadSession:
        safe_name = Path(filename or "document").name
        if not safe_name:
            raise ValueError("filename is required")
        if size <= 0:
            raise ValueError("file size must be positive")
        if size > self.max_total_bytes:
            raise ValueError("file exceeds chunked upload limit")
        if expected_sha256:
            expected_sha256 = expected_sha256.lower().strip()
            if len(expected_sha256) != 64 or any(c not in "0123456789abcdef" for c in expected_sha256):
                raise ValueError("expected_sha256 must be a 64-character hex digest")

        upload_id = uuid.uuid4().hex
        total_chunks = math.ceil(size / self.chunk_size)
        session = UploadSession(
            id=upload_id,
            filename=safe_name,
            size=size,
            chunk_size=self.chunk_size,
            total_chunks=total_chunks,
            source_language=source_language,
            target_language=target_language,
            output_format=output_format,
            glossary=dict(glossary or {}),
            expected_sha256=expected_sha256,
        )
        with self._lock:
            self._chunks_dir(upload_id).mkdir(parents=True, exist_ok=True)
            self._save(session)
        return session

    def load(self, upload_id: str) -> UploadSession:
        path = self._meta_path(upload_id)
        if not path.is_file():
            raise KeyError(upload_id)
        return UploadSession.from_dict(json.loads(path.read_text(encoding="utf-8")))

    def received_indices(self, session: UploadSession) -> list[int]:
        received: list[int] = []
        chunks_dir = self._chunks_dir(session.id)
        if not chunks_dir.is_dir():
            return received
        for path in chunks_dir.glob("*.part"):
            try:
                index = int(path.stem)
            except ValueError:
                continue
            if 0 <= index < session.total_chunks and path.stat().st_size == self.expected_chunk_size(session, index):
                received.append(index)
        return sorted(received)

    def expected_chunk_size(self, session: UploadSession, index: int) -> int:
        if index < 0 or index >= session.total_chunks:
            raise IndexError(index)
        if index < session.total_chunks - 1:
            return session.chunk_size
        return session.size - session.chunk_size * (session.total_chunks - 1)

    def public_status(self, session: UploadSession) -> dict[str, Any]:
        received = self.received_indices(session)
        received_bytes = sum(self.expected_chunk_size(session, i) for i in received)
        return {
            "upload_id": session.id,
            "filename": session.filename,
            "size": session.size,
            "chunk_size": session.chunk_size,
            "total_chunks": session.total_chunks,
            "received_indices": received,
            "received_bytes": received_bytes,
            "progress": int((received_bytes / session.size) * 100) if session.size else 0,
            "status": session.status,
            "job_id": session.job_id,
            "sha256": session.sha256,
            "source_language": session.source_language,
            "target_language": session.target_language,
            "output_format": session.output_format,
            "created_at": session.created_at,
            "updated_at": session.updated_at,
        }

    def put_chunk(self, upload_id: str, index: int, data: bytes, expected_sha256: str | None = None) -> dict[str, Any]:
        session = self.load(upload_id)
        if session.status not in {"uploading", "assembling"}:
            raise ValueError(f"upload is not writable in status {session.status}")
        expected_size = self.expected_chunk_size(session, index)
        if len(data) != expected_size:
            raise ValueError(f"chunk {index} has {len(data)} bytes; expected {expected_size}")

        digest = hashlib.sha256(data).hexdigest()
        if expected_sha256:
            expected_sha256 = expected_sha256.lower().strip()
            if digest != expected_sha256:
                raise ValueError("chunk SHA-256 mismatch")

        path = self._chunk_path(upload_id, index)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.is_file() and path.stat().st_size == expected_size:
            existing_digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if existing_digest == digest:
                return {"ok": True, "index": index, "sha256": digest, "already_received": True}

        tmp = path.with_suffix(".uploading")
        tmp.write_bytes(data)
        tmp.replace(path)
        self._save(session)
        return {"ok": True, "index": index, "sha256": digest, "already_received": False}

    def assign_job(self, session: UploadSession, job_id: str | None = None) -> UploadSession:
        if not session.job_id:
            session.job_id = job_id or uuid.uuid4().hex
        session.status = "assembling"
        self._save(session)
        return session

    def assemble(self, session: UploadSession, destination: Path) -> str:
        received = self.received_indices(session)
        expected = list(range(session.total_chunks))
        if received != expected:
            missing = [i for i in expected if i not in set(received)]
            raise ValueError(f"upload incomplete; missing chunks: {missing[:20]}")

        destination.parent.mkdir(parents=True, exist_ok=True)
        tmp = destination.with_suffix(destination.suffix + ".assembling")
        digest = hashlib.sha256()
        written = 0
        with tmp.open("wb") as out:
            for index in expected:
                chunk_path = self._chunk_path(session.id, index)
                with chunk_path.open("rb") as inp:
                    while True:
                        buf = inp.read(1024 * 1024)
                        if not buf:
                            break
                        out.write(buf)
                        digest.update(buf)
                        written += len(buf)

        if written != session.size:
            tmp.unlink(missing_ok=True)
            raise ValueError(f"assembled file has {written} bytes; expected {session.size}")
        file_sha256 = digest.hexdigest()
        if session.expected_sha256 and file_sha256 != session.expected_sha256:
            tmp.unlink(missing_ok=True)
            raise ValueError("assembled file SHA-256 mismatch")
        tmp.replace(destination)

        session.sha256 = file_sha256
        session.status = "assembled"
        self._save(session)
        return file_sha256

    def mark_completed(self, session: UploadSession, sha256: str | None = None) -> None:
        if sha256:
            session.sha256 = sha256
        session.status = "completed"
        self._save(session)
        shutil.rmtree(self._chunks_dir(session.id), ignore_errors=True)

    def cancel(self, upload_id: str) -> None:
        directory = self._dir(upload_id)
        if not directory.exists():
            raise KeyError(upload_id)
        shutil.rmtree(directory)
